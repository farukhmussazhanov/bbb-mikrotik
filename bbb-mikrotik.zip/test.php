<?php
require_once "classes/autoload.php";
//echo Auth::addUser("admin","12345");
session_start();
session_destroy();